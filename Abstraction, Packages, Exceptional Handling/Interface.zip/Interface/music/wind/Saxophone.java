package music.wind;

import music.Playable;

public class Saxophone implements Playable{
	
	public void play() {
		System.out.println("Playing Saxophone");
	}

}
