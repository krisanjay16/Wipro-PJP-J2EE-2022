package com.wipro.automobile.ship;

public class Assignment2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Compartment compartment = new Compartment(100.15, 999.5, 123);
		
		System.out.println(compartment);

	}

}
