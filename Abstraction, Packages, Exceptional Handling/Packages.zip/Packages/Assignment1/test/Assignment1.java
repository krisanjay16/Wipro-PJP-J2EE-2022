package test;

public class Assignment1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Foundation foundation=new Foundation();
		foundation.variable2=2;
		foundation.variable3=3;
		foundation.variable4=4;
		System.out.println("Variable1 cant be accessed, Since its a private variable");
		System.out.println("Variable2: "+foundation.variable2);
		System.out.println("Variable3: "+foundation.variable3);
		System.out.println("Variable4: "+foundation.variable4);
	}

}
