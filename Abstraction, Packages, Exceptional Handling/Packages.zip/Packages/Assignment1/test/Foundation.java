package test;

public class Foundation {
	private int variable1;
	int variable2;
	protected int variable3;
	public int variable4;
}
