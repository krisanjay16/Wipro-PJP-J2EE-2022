package com.mile1.exception;

public class NullStudentObjectException extends Exception {
	public String toString()  {
		return "Object is null" ;
	}
}
