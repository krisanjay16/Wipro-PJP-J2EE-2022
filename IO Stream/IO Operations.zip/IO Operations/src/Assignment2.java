import java.io.*;
import java.util.*;
public class Assignment2{
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the input file name: ");
		String inputFilename = scanner.nextLine();
		System.out.println("Enter the output file name: ");
		String outputFilename = scanner.nextLine();
	
		File filein = new File(inputFilename);
		File fileout = new File(outputFilename);
		
		BufferedReader bufferedReader = new BufferedReader(new FileReader(filein));
		BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(fileout));
		
		int ch;
		while ((ch = bufferedReader.read()) != -1) {
			bufferedWriter.write(ch);
		};
		System.out.println("File is copied");
		bufferedReader.close();
		bufferedWriter.close();
		scanner.close();
	}
}