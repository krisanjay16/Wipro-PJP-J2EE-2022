import java.io.*;
import java.util.*;
public class Assignment1 {
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		System.out.print("Enter the file name: ");
		String filename=scanner.nextLine();
		System.out.print("Enter the character to be counted: ");
		char temp=scanner.next().charAt(0);
		scanner.close();
		File file=new File(filename);
		int charCount=0;
		BufferedReader bufferedReader=new BufferedReader(new FileReader(file));
		int ch;
		do {
			ch=bufferedReader.read();
			if(ch>=65 && ch<=90)ch+=32;
			if(temp>=65 && temp<=90) temp +=32;
			if(ch==temp)
				charCount++;
		}while(ch!=-1);
		System.out.println("File "+"'"+filename+"'"+" has "+charCount+" instance of letter "+temp+".");
		bufferedReader.close();
	}

}
