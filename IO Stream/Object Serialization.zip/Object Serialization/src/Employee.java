import java.io.*;
import java.util.*;

public class Employee implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String name;
	private String dob;
	private String department;
	private String designation;
	private double salary;
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}
	

	public String toString() {
		return "employee [name=" + name + ", dob=" + dob + ", department=" + department + ", designation=" + designation
				+ ", salary=" + salary + "]";
	}

	public static void main(String[] args)throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		Employee employee=new Employee();
		
		System.out.print("Enter name: ");
		employee.setName(scanner.nextLine());
		System.out.print("Enter D.O.B.: ");
		employee.setDob(scanner.nextLine());
		System.out.print("Enter department: ");
		employee.setDepartment(scanner.nextLine());
		System.out.print("Enter designation: ");
		employee.setDesignation(scanner.nextLine());
		System.out.print("Enter salary: ");
		employee.setSalary(scanner.nextDouble());
		scanner.nextLine();
		
		FileOutputStream fileOutputStream = new FileOutputStream("data");
		ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
		objectOutputStream.writeObject(employee);
		
		FileInputStream fileInputStream = new FileInputStream("data");
		ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
		Employee employee2 = (Employee) objectInputStream.readObject();
		
		System.out.println("Name: " + employee2.getName());
		System.out.println("D.O.B.: " + employee2.getDob());
		System.out.println("Department: " + employee2.getDepartment());
		System.out.println("Designation: " + employee2.getDesignation());
		System.out.println("Salary: " + employee2.getSalary());
		
		
		fileOutputStream.close();
		objectOutputStream.close();
		fileInputStream.close();
		objectInputStream.close();
		scanner.close();
		

	}

}
