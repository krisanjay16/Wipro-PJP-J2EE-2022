import org.junit.*;
import org.junit.runner.JUnitCore;
import com.wipro.test.JunitTestSuite;
public class TestRunner {
	@Test
	public void main() {
		JUnitCore.runClasses(JunitTestSuite.class);
	}

}
