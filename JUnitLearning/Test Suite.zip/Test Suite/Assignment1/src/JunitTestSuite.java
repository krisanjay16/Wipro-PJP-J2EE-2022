
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.wipro.test.TestCheckPresence;
import com.wipro.test.TestSort;
import com.wipro.test.TestStringConcat;

@RunWith(Suite.class)
@Suite.SuiteClasses({
	TestStringConcat.class,TestCheckPresence.class,TestSort.class
})

public class JunitTestSuite {

}
